<?php
//--------------------------------------------------------------------
// Xaraya mod_login_to_xaraya class
// -- Crisitan Deacu - Initial login/logout code
// -- Brian McCloskey - Updated
//    * Converted to a class
//    * Added failsafe code to check if user is "deleted" in Xaraya
//      while the user is logging into IPB ("recalls" user in Xaraya)
//    * Added xaraya_delete function
//    * Added xaraya_update_email function
//    * Added xaraya_group_change function (sets account in Xaraya to
//      inactive if users primary group in IPB is set to "Banned"
//    * Added xaraya_name_change function
//--------------------------------------------------------------------
class mod_login_to_xaraya {
   var $xarDB;
   var $ipb_pfx = "";
   var $xar_pfx = "";
   var $ipb_db = "";
   var $xar_db = "";
   var $db_change = 0;

   //-------------------
   // Class constructor
   //-------------------
   function mod_login_to_xaraya() {
      global $DB, $ibforums, $std, $INFO;

      //-------------------------
      // Setup the DB connection
      //-------------------------
      $this->xarDB = new db_driver;
      $this->xarDB->obj['sql_database'] = $INFO['sql_xaraya_database'];
      $this->xarDB->obj['sql_user'] = $INFO['sql_xaraya_user'];
      $this->xarDB->obj['sql_pass'] = $INFO['sql_xaraya_pass'];
      $this->xarDB->obj['sql_host'] = $INFO['sql_xaraya_host'];
      $this->xarDB->obj['sql_tbl_prefix'] = $INFO['sql_xaraya_tbl_prefix'];
      $this->xarDB->obj['sql_debug'] = $INFO['sql_xaraya_debug'];
      $this->xarDB->connect();
      $this->ipb_pfx = $INFO['sql_tbl_prefix'];
      $this->xar_pfx = $INFO['sql_xaraya_tbl_prefix'];
      $this->ipb_db = $INFO['sql_database'];
      $this->xar_db = $INFO['sql_xaraya_database'];
      //----------------------------------------------------------------
      // If the connection parameters for the Xaraya DB are the same as
      // that used for IPB, the DB resource link will be the same.  Due
      // to this, the database used must be forced, and we determine
      // this need here.
      //----------------------------------------------------------------
      if ($INFO['sql_host'] == $INFO['sql_xaraya_host'] &&
          $INFO['sql_user'] == $INFO['sql_xaraya_user']) {
         $this->db_change = 1;
         mysql_select_db($this->ipb_db);
      }
   }

   //-------------------
   // Xaraya login user
   //-------------------
   function xaraya_login($member) {
      global $DB, $ibforums, $std;

      $username = $member['name'];

      if ($this->db_change) { mysql_select_db($this->xar_db); }
      //----------------------
      // Get User details
      //----------------------
      $this->xarDB->query("SELECT * FROM ".$this->xar_pfx."roles WHERE xar_name='".$username."'");
      if ($this->xarDB->get_num_rows()) {
         //----------------------
         // User already exists
         //----------------------
         $xar_member = $this->xarDB->fetch_row();
         $xar_uid = $xar_member['xar_uid'];
         //------------------------------------------------------
         // Still need to check if the user is possibly in the
         // deleted state, and "recall" the user.  If the user
         // is logging in, then this is valid since this means
         // the user was recreated (or possibly manually deleted
         // in Xaraya for some odd reason).
         //------------------------------------------------------
         if (ereg("deleted", $xar_member['xar_uname'])) {
            $this->xarDB->query("UPDATE ".$this->xar_pfx."roles SET xar_uname='".$xar_member['xar_name']."', xar_state='3' WHERE xar_name='".$xar_member['xar_name']."'");
         }
      } else {
         //----------------------
         // Create role entries
         //----------------------
         if ($this->db_change) { mysql_select_db($this->ipb_db); }

         $DB->query("SELECT email,joined FROM ".$this->ipb_pfx."members WHERE id='".$member['id']."'");
         if ($row = $DB->fetch_row()) {
            if ($this->db_change) { mysql_select_db($this->xar_db); }
            $db_string = $this->xarDB->compile_db_insert_string( array(
               'xar_uid'         => '',
               'xar_name'        => $username,
               'xar_type'        => 0,
               'xar_users'       => 0,
               'xar_uname'       => $username,
               'xar_email'       => $row['email'],
               'xar_pass'        => $member['pass'],
               'xar_date_reg'    => $row['joined'],
               'xar_valcode'     => 'createdbyipb',
               'xar_state'       => 3,
               'xar_auth_module' => 'authinvision2' ));

            $dbquery = "INSERT INTO ".$this->xar_pfx."roles (".$db_string['FIELD_NAMES'].") VALUES (".$db_string['FIELD_VALUES'].")";
            $this->xarDB->query($dbquery);
            $xar_uid = $this->xarDB->get_insert_id();
            $db_string = $this->xarDB->compile_db_insert_string( array(
               'xar_uid'         => $xar_uid,
               'xar_parentid'    => 5 ));
            $dbquery = "INSERT INTO ".$this->xar_pfx."rolemembers (".$db_string['FIELD_NAMES'].") VALUES (".$db_string['FIELD_VALUES'].")";
            $this->xarDB->query($dbquery);
         }
      }

      //-----------------------
      // Check for Remember me
      //-----------------------
      if ($ibforums->input['CookieDate']) {
         $sticky = 1;
      } else {
        $sticky = 0;
      }

      //-------------------------------------------
      // Time to authenticate to Xaraya officially
      //-------------------------------------------
      if ($this->db_change) { mysql_select_db($this->xar_db); }
      //---------------------
      // Create session vars
      //---------------------
      srand((double) microtime() * 1000000);
      $xar_rand = rand();
      $vars = "XARSVuid|".serialize($xar_uid)."XARSVrand|".serialize($xar_rand)."XARSVnavigationLocale|".serialize("en_US.utf-8")."XARSVauthenticationModule|".serialize("authinvision2");
      if ($session_id = $std->my_getcookie('XARAYASID')) {
         //------------------------------
         // Update the anonymous session
         //------------------------------
         $now = time();
         $this->xarDB->query("UPDATE ".$this->xar_pfx."session_info set xar_uid='".$xar_uid."', xar_lastused='".$now."', xar_vars='".$vars."', xar_remembersess='".$sticky."' WHERE xar_sessid='".$session_id."'");
         //$this->xarDB->query("DELETE FROM ".$this->xar_pfx."session_info WHERE xar_sessid = '".$session_id."'");
      } else {
         $session_id = md5( uniqid(microtime()) );
         //------------------------------------------------------------
         // The cookie may have been destroyed, so try and cleanup the
         // sessions table, including removing guest entries with the
         // requesting IP Address since we are creating a new one.
         //------------------------------------------------------------
         $this->xarDB->query("DELETE FROM ".$this->xar_pfx."session_info WHERE xar_uid='2' AND xar_ipaddr='".$ibforums->input['IP_ADDRESS']."'");
         //---------------------
         // Insert session info
         //---------------------
         $now = time();
         $db_string = $this->xarDB->compile_db_insert_string( array(
            'xar_sessid'        => $session_id,
            'xar_ipaddr'        => $ibforums->input['IP_ADDRESS'],
            'xar_firstused'     => $now,
            'xar_lastused'      => $now,
            'xar_uid'           => $xar_uid,
            'xar_vars'          => $vars,
            'xar_remembersess'  => $sticky ));
         $dbquery = "INSERT INTO ".$this->xar_pfx."session_info (".$db_string['FIELD_NAMES'].") VALUES (".$db_string['FIELD_VALUES'].")";
         $this->xarDB->query($dbquery);
      }

      //----------------
      // Set the cookie
      //----------------
      $end = time() + 31536000;
      setcookie("XARAYASID",$session_id,$end,$ibforums->vars['cookie_path'],$ibforums->vars['cookie_domain']);
      //$std->my_setcookie("XARAYASID", $session_id, $sticky);

      if ($this->db_change) { mysql_select_db($this->ipb_db); }
   }

   //--------------------
   // Xaraya logout user
   //--------------------
   function xaraya_logout() {
      global $DB, $ibforums, $std;

      if ($this->db_change) { mysql_select_db($this->xar_db); }
      //----------------------------------------
      // Attempt to logout the user from Xaraya
      //----------------------------------------
      $xar_rand = rand();
      $vars = "XARSVuid|".serialize("2")."XARSVrand|".serialize($xar_rand)."XARSVnavigationLocale|".serialize("en_US.utf-8");
      if ($cookie_id = $std->my_getcookie('XARAYASID')) {
         $now = time();
         $this->xarDB->query("UPDATE ".$this->xar_pfx."session_info SET xar_uid='2', xar_lastused='".$now."', xar_vars='".$vars."', xar_remembersess='0' WHERE xar_sessid='".$cookie_id."'");
         //$this->xarDB->query("DELETE FROM ".$this->xar_pfx."session_info WHERE xar_sessid = '".$cookie_id."'");
      }

      if ($this->db_change) { mysql_select_db($this->ipb_db); }
   }

   //--------------------
   // Xaraya delete user
   //--------------------
   function xaraya_delete($ids,$type) {
      global $DB, $ibforums, $std;

      if ($type == 'arr') {
         foreach ($ids as $k => $v) {
            if ($this->db_change) { mysql_select_db($this->ipb_db); }
            $DB->query("SELECT name FROM ".$this->ipb_pfx."members WHERE id='".$v."'");
            if ($row = $DB->fetch_row()) {
               if ($this->db_change) { mysql_select_db($this->xar_db); }
               $this->xarDB->query("UPDATE ".$this->xar_pfx."roles SET xar_uname='".$row['name']."[deleted]".mktime()."',xar_state=0 WHERE xar_name='".$row['name']."'");
            }
         }
      } else {
         if ($this->db_change) { mysql_select_db($this->ipb_db); }
         $DB->query("SELECT name FROM ".$this->ipb_pfx."members where id='".$ids."'");
         if ($row = $DB->fetch_row()) {
            if ($this->db_change) { mysql_select_db($this->xar_db); }
            $this->xarDB->query("UPDATE ".$this->xar_pfx."roles SET xar_uname='".$row['name']."[deleted]".mktime()."',xar_state=0 WHERE xar_name='".$row['name']."'");
         }
      }
      if ($this->db_change) { mysql_select_db($this->ipb_db); }
   }

   //----------------------
   // Xaraya update e-mail
   //----------------------
  function xaraya_update_email($id, $email) {
      global $DB, $ibforums, $std;

      $DB->query("SELECT name FROM ".$this->ipb_pfx."members WHERE id='".$id."'");
      if ($row = $DB->fetch_row()) {
         if ($this->db_change) { mysql_select_db($this->xar_db); }
         $this->xarDB->query("UPDATE ".$this->xar_pfx."roles SET xar_email='".$email."' WHERE xar_uname='".$row['name']."'");
      }
      if ($this->db_change) { mysql_select_db($this->ipb_db); }
   }

   //------------------------
   // Xaraya disable account
   //------------------------
   function xaraya_group_change($id,$group) {
      global $DB, $ibforums, $std;

      if ($this->db_change) { mysql_select_db($this->ipb_db); }
      $DB->query("SELECT g_id FROM ".$this->ipb_pfx."groups WHERE g_title='Banned'");
      if ($row1 = $DB->fetch_row()) {
         $DB->query("SELECT name FROM ".$this->ipb_pfx."members WHERE id='".$id."'");
         if ($row2 = $DB->fetch_row()) {
            //-----------------------------------------
            // Check if the new real group is "Banned"
            //-----------------------------------------
            if ($row1['g_id'] == $group) {
               //--------------------------------
               // Set Xaraya account to disabled
               //--------------------------------
               if ($this->db_change) { mysql_select_db($this->xar_db); }
               $this->xarDB->query("UPDATE ".$this->xar_pfx."roles SET xar_state='1' WHERE xar_uname='".$row2['name']."'");
            } else {
               //------------------------------
               // Force account back to Active
               //------------------------------
               if ($this->db_change) { mysql_select_db($this->xar_db); }
               $this->xarDB->query("UPDATE ".$this->xar_pfx."roles SET xar_state='3' WHERE xar_uname='".$row2['name']."'");
            }
         }
      }
      if ($this->db_change) { mysql_select_db($this->ipb_db); }
   }

   //--------------------
   // Xaraya name change
   //--------------------
   function xaraya_name_change($id,$new_name,$old_name) {
      global $DB, $ibforums, $std;

      //--------------------
      // Update Xaraya user
      //--------------------
      if ($this->db_change) { mysql_select_db($this->xar_db); }
      $this->xarDB->query("UPDATE ".$this->xar_pfx."roles SET xar_name='".$new_name."', xar_uname='".$new_name."' WHERE xar_uname='".$old_name."'");
      if ($this->db_change) { mysql_select_db($this->ipb_db); }
   }

   //------------------
   // Class destructor
   //------------------
   function destroy() {
      $this->xarDB->close_db();
   }

}

?>
