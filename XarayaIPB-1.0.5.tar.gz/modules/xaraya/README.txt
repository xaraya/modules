//==============//
// Instructions //
//==============//

**********
** NOTE **
**********
These instructions are out of date.  For the latest instuctions on configuring
the mod_login_to_xaraya module, please visit http://www.xaraya.com/ and
navigate to Documentation -> Tutorials & Guides -> Configure & Build Tutorials
and reference the Authinvision2 module documentation.



===========
= UPLOADS =
===========
module/xaraya/mod_login_to_xaraya.php
module/ipb_member_sync.php



=========================
= FILE: conf_global.php =
=========================
This file is modified in order to add SQL information
required for the Xaraya database (uses IPB's DB class).

ADD BEFORE ?>

// Xaraya variables used for member sync fill in with your specifics
$INFO['sql_xaraya_driver']              =      'mysql';
$INFO['sql_xaraya_host']                =      'localhost';
$INFO['sql_xaraya_database']            =      '';
$INFO['sql_xaraya_user']                =      '';
$INFO['sql_xaraya_pass']                =      '';
$INFO['sql_xaraya_tbl_prefix']          =      'xar_';
$INFO['sql_xaraya_debug']               =      '0';
$INFO['xaraya_locale']                  =      'en_US.utf-8';

===========================
= FILE: sources/login.php =
===========================

FIND
function do_log_out()
{
  global $std, $ibforums, $DB, $print, $sess;


ADD BELOW
   if ( USE_MODULES == 1 )
   {
      $this->modules->register_class(&$this);
      $this->modules->on_logout();
   }


=====================================
= FILE: sources/admin/ad_member.php =
=====================================

FIND
function member_change_name_complete()
{
  global $ibforums, $DB,  $std, $HTTP_POST_VARS;


ADD BELOW

  if ( USE_MODULES == 1 )
  {
  $this->modules->register_class(&$this);
  $this->modules->on_name_change($mid, $new_name );
  }

FIND
  $ibforums->admin->save_log("Changed Member Name '{$member['name']}' to '$new_name'");

  if ( USE_MODULES == 1 )
  {
  $this->modules->register_class(&$this);
  $this->modules->on_name_change($mid, $new_name );
  }

CHANGE TO
  $ibforums->admin->save_log("Changed Member Name '{$member['name']}' to '$new_name'");

  /*- if ( USE_MODULES == 1 )
  {
  $this->modules->register_class(&$this);
  $this->modules->on_name_change($mid, $new_name );
  } -*/

FIND
function member_delete_do($id)
{
  global $ibforums, $DB,  $std;

ADD BELOW

  if ( USE_MODULES == 1 )
  {
  $this->modules->register_class(&$this);
  $this->modules->on_delete($id);
  }

FIND
  if ( count($stats) > 0 )
  {
  $DB->simple_exec_query( array( 'delete' => 'cache_store', 'where' => "cs_key='stats'" ) );
  $DB->do_insert( 'cache_store', array( 'cs_array' => 1, 'cs_key' => 'stats', 'cs_value' => addslashes(serialize($stats)) ) );
  }

  if ( USE_MODULES == 1 )
  {
  $this->modules->register_class(&$this);
  $this->modules->on_delete($id);
  }

CHANGE TO
  if ( count($stats) > 0 )
  {
  $DB->simple_exec_query( array( 'delete' => 'cache_store', 'where' => "cs_key='stats'" ) );
  $DB->do_insert( 'cache_store', array( 'cs_array' => 1, 'cs_key' => 'stats', 'cs_value' => addslashes(serialize($stats)) ) );
  }

  /*- if ( USE_MODULES == 1 )
  {
  $this->modules->register_class(&$this);
  $this->modules->on_delete($id);
  } -*/



=======================
= ipb_member_sync.php =
=======================

FIND
class ipb_member_sync
{
var $class = "";

ADD BELOW
var $xaraya;

FIND
function ipb_member_sync()
{

ADD BELOW
  require 'xaraya/mod_login_to_xaraya.php';
  $this->xaraya = new mod_login_to_xaraya();

FIND
function on_login($member=array())
{
  global $DB, $std, $ibforums;

  //---- START



ADD BELOW
  $this->xaraya->xaraya_login($member);

FIND
//-----------------------------------------------
// on_delete($ids)
//
// $ids = array | integer
// If array, will contain list of ids
//-----------------------------------------------

ADD ABOVE
//-----------------------------------------------
// on_logout()
//
//-----------------------------------------------

function on_logout()
{
  global $DB, $std, $ibforums;

  //---- START

  $this->xaraya->xaraya_logout();

  //---- END
}

FIND
  else
  {
  $type = 'int';
  }



  //---- END
}

//-----------------------------------------------
// on_email_change($id, $new_email)
//
// $id        = int member_id

ADD ABOVE //---- END
  $this->xaraya->xaraya_delete($ids,$type);

FIND
function on_email_change($id, $new_email)
{
  global $DB, $std, $ibforums;

  //---- START

ADD BELOW

  $this->xaraya->xaraya_update_email($id, $new_email);

FIND
function on_group_change( $id, $new_group )
{
  global $DB, $std, $ibforums;

  //---- START

ADD BELOW

  $this->xaraya->xaraya_group_change($id,$new_group);


FIND
function on_name_change( $id, $new_name )
{
  global $DB, $std, $ibforums;

  //---- START

ADD BELOW

  $this->xaraya->xaraya_name_change($id, $new_name);



