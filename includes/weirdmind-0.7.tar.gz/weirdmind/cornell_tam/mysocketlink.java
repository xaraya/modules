
/*
    mysocketlink.java -- plug together MindTerm and WeirdX
    Copyright (C) 2001  Stephen D. Holland

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

package cornell_tam;

import java.net.*;
import java.io.*;
import java.util.*;
import java.applet.Applet;

public class mysocketlink  {
    static mysocketlink socketlink; /* only one allowed */
    PipedOutputStream ToXClient;
    PipedInputStream FromXClient;
    String OriginHost;
    static Vector Acl;
    static String properties_url;


    class mysocketimpl extends SocketImpl {
        InputStream Readable;
	OutputStream Writable;
	String OriginHost;


	mysocketimpl(InputStream Readable, OutputStream Writable,String OriginHost) {
	    this.Readable=Readable;
	    this.Writable=Writable;
	    this.OriginHost=OriginHost;
	}

	protected int available() throws IOException {
	    return Readable.available();
	}

	protected void close() throws IOException {
	    Readable.close();
	    Readable=null;
	    Writable.close();
	    Writable=null;
	}
	
	protected InputStream getInputStream() {
	    return Readable;
	}

	protected OutputStream getOutputStream() {
	    return Writable;
	}

	protected InetAddress getInetAddress() {
	    try {
		if (Acl==null) {
		    /* tell the truth if we're not doing the protection ourself */
		    return InetAddress.getByName(OriginHost);
		} else {
		    /* otherwise, pretend it was local (makes netscape happy) */
		    return InetAddress.getLocalHost();
		}
	    } catch (UnknownHostException e) {
		return null;
	    }
	}

	/* dummy members */
	protected void accept(SocketImpl s) {}
	protected void bind(InetAddress host,int port) {}
	protected void connect(InetAddress host,int port) {}
	protected void connect(String host,int port) {}
	protected void create(boolean stream) {}
	protected FileDescriptor getFileDescriptor() {return null;}
	protected int getPort() {return 0;}
	protected void listen(int backlog) {}
	protected void shutdownInput() {}
	protected void shutdownOutput() {}
        public void setOption(int optID,Object value) {}
        public Object getOption(int optID) throws SocketException {return null;}
    }

    class mysocket extends Socket {
         

        public mysocket(SocketImpl Impl) throws SocketException {
	    super(Impl);
	}
    
    }

    public mysocketlink(InetAddress serveraddr)  {

	if (socketlink==null) {
	    socketlink=this;
	}

	final String ServerString=serveraddr.getHostAddress();


	/* get WeirdX started */
	Thread WeirdXThread;
	System.err.println("Starting WeirdX...");

	
	WeirdXThread=new Thread(new Runnable() {public void run() {
	    
	    System.err.println("About to set property");
	    
	    /* set properties */ 
	    //System.setProperty("weirdx.display.visual","TrueColor16");
	    // System.setProperty("weirdx.windowmode","MultiWindow"); 
	    System.err.println("Property set");
	    
	    /* If no ACL has been set (through APPLET tag),
	       we're not providing host based access control, 
	       so we need WeirdX to provide that -- turn it on! */
	    if (Acl==null) {
		System.err.println("Using WeirdX native ACL. Allowing access to "+ServerString);
		System.setProperty("weirdx.display.acl","-,"+ServerString);
	    } else {
		System.err.println("Using socketlink ACL. "+Acl.size()+" entries.");
	    }
	    
	    if (properties_url != null) {
		String[] params=new String[2];
		params[0]="";
		params[1]=properties_url;
		com.jcraft.weirdx.WeirdX.main(params); 
	    } else {
		com.jcraft.weirdx.WeirdX.main(null); 
	    }
	}});
	WeirdXThread.start();
    }

    public static void SetAcl(Applet MTApplet) {
	if (Acl==null)
	    Acl=new Vector();

	int cnt;

	for (cnt=1;;cnt++) {
	    String ParamName="socketlink.allowhost"+cnt;
	    String AclEntry=MTApplet.getParameter(ParamName);
	    if (AclEntry != null)
		Acl.addElement(AclEntry);
	    else break;
	}

	/* also extract the properties URL */
	properties_url=MTApplet.getParameter("properties_url");
    }

    public static mysocketlink getmysocketlink() {
	return socketlink;
    }
    
    public synchronized Socket accept() throws SocketException {
	/* wait for a connection */
	System.err.println("Server waiting for connection...");
 	while (ToXClient == null || FromXClient == null) {
	    try {
		wait();
	    } catch(Exception e) {
		
	    }
	}
	Socket toReturn=new mysocket(new mysocketimpl(FromXClient,ToXClient,OriginHost));
	FromXClient=null;
	ToXClient=null;
	
	notifyAll();
	System.err.println("X server accepted remote connection");

	return toReturn;
    }


    boolean CheckAcl(String Host) {
	Enumeration e;
	String Test;

	for (e=Acl.elements();e.hasMoreElements();) {
	    Test=(String)e.nextElement();
	    //System.err.println("Test: "+Test+" Host: "+Host);
	    if (Test.equals(Host)) 
		return true;
     

	}
	return false;
    }

    public synchronized Socket connect(String origin) throws IOException {
	/* perform a connection */
	
	System.err.println("mysocketlink.connect("+origin+")");

	if (!origin.startsWith("X11 connection from "))
	    throw new IOException("Bad origin: "+origin);
	String hoststring=origin.substring(20);
	int hostend=0;
	while (hoststring.charAt(hostend) != ' ') hostend++;
	String originhost=hoststring.substring(0,hostend);

	if (Acl != null) { 
	    if (!CheckAcl(originhost)) {
		System.err.println("Connection from host "+originhost+" denied (Not found in ACL)");
		throw new IOException("Connection from host "+originhost+" denied (Not found in ACL)");
	    }
	}
 	while (ToXClient != null || FromXClient != null) {
	    try {
		wait();
	    } catch(Exception e) {
		
	    }
	}

	System.err.println("Opening remote connection to X server");
	System.err.println("Origin host = \""+originhost+"\"");

	PipedOutputStream ToXServer=new AutoFlushPipedOutputStream();
	PipedInputStream FromXServer=new PipedInputStream();
	
	
	ToXClient=new AutoFlushPipedOutputStream(FromXServer);
	FromXClient=new PipedInputStream(ToXServer);
	OriginHost=originhost;

	notifyAll();

	return new mysocket(new mysocketimpl(FromXServer,ToXServer,OriginHost));

    }

}


