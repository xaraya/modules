//
// DUMMY CLASS TO MAKE COMPILER HAPPY WHEN NOT USING NETSCAPE_SECURITY_MODEL
//
package netscape.security;

public class ForbiddenTargetException extends Exception {
}
