/******************************************************************************
 *
 * Copyright (c) 1998,99 by Mindbright Technology AB, Stockholm, Sweden.
 *                 www.mindbright.se, info@mindbright.se
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 *****************************************************************************
 * $Author: mats $
 * $Date: 2000/07/05 16:13:39 $
 * $Name: rel1-2-1 $
 *****************************************************************************/
package mindbright.terminal;

import java.io.IOException;

public interface TerminalListener {
  public void typedChar(char c) throws IOException;
  public void sendBytes(byte[] b) throws IOException;
  public void signalWindowChanged(int rows, int cols, int vpixels, int hpixels);
}
