/******************************************************************************
 *
 * Copyright (c) 2000 by Mindbright Technology AB, Stockholm, Sweden.
 *                 www.mindbright.se, info@mindbright.se
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 *****************************************************************************
 * $Author: mats $
 * $Date: 2000/05/18 11:43:58 $
 * $Name: rel1-2-1 $
 *****************************************************************************/
package mindbright.security;

public class SimpleHMAC extends HMAC {
    MessageDigest hash;
    byte[]        key;
    
    SimpleHMAC(String algorithmSpec) throws NoSuchAlgorithmException {
	algorithmSpec = parseAlgorithmSpec(algorithmSpec);

	try {
	    hash = MessageDigest.getInstance(algorithmSpec);
	} catch(InstantiationException ie) {
	    throw new NoSuchAlgorithmException();
	} catch(IllegalAccessException ia) {
	    throw new NoSuchAlgorithmException();
	} catch(ClassNotFoundException ce) {
	    throw new NoSuchAlgorithmException();
	}

	if(macLength == -1) {
	    macLength = hash.hashSize();
	} else {
	    // !!! TODO: Check this, awkward different naming convention?
	    macLength = 8 * macLength;
	}
	blockSize = hash.blockSize();
    }

    public void init(byte[] key) {
	this.key = key;
    }

    public byte[] digest(byte[] data, int off, int len) {
	hash.update(key);
	hash.update(data, off, len);
	hash.update(key);
	byte[] dig = hash.digest();
	byte[] hmac = new byte[macLength];
	System.arraycopy(dig, 0, hmac, 0, macLength);
	return hmac;
    }

    public int hashSize() {
	return hash.hashSize();
    }

}
