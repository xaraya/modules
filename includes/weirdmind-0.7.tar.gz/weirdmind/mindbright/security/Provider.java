/******************************************************************************
 *
 * Copyright (c) 1998,99 by Mindbright Technology AB, Stockholm, Sweden.
 *                 www.mindbright.se, info@mindbright.se
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 *****************************************************************************
 * $Author: mats $
 * $Date: 2000/03/23 10:54:35 $
 * $Name: rel1-2-1 $
 *****************************************************************************/
package mindbright.security;

import java.util.Properties;
import java.util.Hashtable;

public class Provider extends Properties {
    String name;
    double version;
    String info;

    // !!! Short circuit
    public static Hashtable providers;
    static {
	providers = new Hashtable();
	providers.put("Mindbright", new mindbright.security.provider.Mindbright());
    };

    protected Provider(String name, double version, String info) {
	this.name    = name;
	this.version = version;
	this.info    = info;
    }

    public void clear() {
    }

    /*
    public Set entrySet() {
    }
    */

    public String getInfo() {
	return info;
    }

    public String getName() {
	return name;
    }

    public double getVersion() {
	return version;
    }

    /*
    public Set keySet() {
    }
    */

    /*
    public void load(InputStream inStream) {
    }
    */

    /*
    public Object put(Object key, Object value) {
	return null;
    }
    */

    /*
    public void putAll(Map t) {
    }
    */

    public Object remove(Object key) {
	return null;
    }

    public String toString() {
	return null;
    }

    /*
    public Collection values() {
    }
    */
}
