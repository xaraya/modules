/******************************************************************************
 *
 * Copyright (c) 1998,99 by Mindbright Technology AB, Stockholm, Sweden.
 *                 www.mindbright.se, info@mindbright.se
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 *****************************************************************************
 * $Author: mats $
 * $Date: 2000/03/20 08:35:27 $
 * $Name: rel1-2-1 $
 *****************************************************************************/
package mindbright.security;

public class AlgorithmParameters {
    protected AlgorithmParameters(AlgorithmParametersSpi paramSpi,
				  Provider provider,
				  String algorithm) {
    }

    public final String getAlgorithm() {
	return null;
    }

    public final byte[] getEncoded() {
	return null;
    }

    public final byte[] getEncoded(String format) {
	return null;
    }

    public final static AlgorithmParameters getInstance(String algorithm) {
	return null;
    }

    public final static AlgorithmParameters getInstance(String algorithm,
						  String provider) {
	return null;
    }

    public final AlgorithmParameterSpec getParameterSpec(Class paramSpec) {
	return null;
    }

    public final Provider getProvider() {
	return null;
    }

    public final void init(AlgorithmParameterSpec paramSpec) {
    }

    public final void init(byte[] params) {
    }

    public final void init(byte[] params, String format) {
    }

    public final String toString() {
	return null;
    }
}
