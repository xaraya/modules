/******************************************************************************
 *
 * Copyright (c) 1998,99 by Mindbright Technology AB, Stockholm, Sweden.
 *                 www.mindbright.se, info@mindbright.se
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 *****************************************************************************
 * $Author: mats $
 * $Date: 1999/07/19 17:13:49 $
 * $Name: rel1-2-1 $
 *****************************************************************************/
package mindbright.security;

public final class NoEncrypt extends Cipher {

  public void encrypt(byte[] src, int srcOff, byte[] dest, int destOff, int len) {
    System.arraycopy(src, srcOff, dest, destOff, len);
  }

  public void decrypt(byte[] src, int srcOff, byte[] dest, int destOff, int len) {
    System.arraycopy(src, srcOff, dest, destOff, len);
  }

  public void setKey(byte[] key) {
  }

}
